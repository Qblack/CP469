//
//  QuestionTableCell.swift
//  blac_a04
//
//  Created by Student on 2015-02-08.
//  Copyright (c) 2015 blac2410. All rights reserved.
//

import UIKit;

class QuestionTableCell: UITableViewCell {
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var questionImage: UIImageView!
}
