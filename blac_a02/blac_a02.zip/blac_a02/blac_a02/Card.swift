//
//  Card.swift
//  blac_a02
//
//  Created by Student on 2015-01-26.
//  Copyright (c) 2015 blac2410. All rights reserved.
//

import Foundation;

struct Card {
    let question:String;
    let answer:String;
    let image:String;
}
			